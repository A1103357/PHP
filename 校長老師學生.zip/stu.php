<?php
session_start();

if(($_SESSION["login"]=="S") || ($_SESSION["login"]=="T")){

}else{
    header("Location:error.php");
}
?>

<html>
<head>
<meta charset="utf-8">
</head>
<body>
此處為學生頁面<br/>
</body>
</html>