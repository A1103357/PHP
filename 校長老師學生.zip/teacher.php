<?php
session_start();

if(($_SESSION["login"]=="P") || ($_SESSION["login"]=="T")){

}else{
    header("Location:error.php");
}
?>

<html>
<head>
<meta charset="utf-8">
</head>
<body>
此處為老師頁面<br/>
若欲前往學生頁面<a href="stu.php">請點選這裡</a>
</body>
</html>