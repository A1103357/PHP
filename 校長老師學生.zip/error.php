<html>
<head>
<meta charset="utf-8">
</head>
<body>
非法進入網頁!<br/>
網頁將於三秒後跳轉到登入網頁或<br/>
<a href=login.php>點選這裡</a>
<?php
header("Refresh:3;url=login.php")
?>
</body>
</html>