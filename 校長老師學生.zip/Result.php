<meta charset="utf8">

<?php
session_start();

$presidentID="president";
$presidentPWD="123";
$teacherID="teacher";
$teacherPWD="456";
$stuID="student";
$stuPWD="789";

$id = $_POST["id"];
$pwd = $_POST["pwd"];

if(($presidentID==$id)&&($presidentPWD==$pwd)){
    $_SESSION["login"]="P";
    header("Location:president.php");
}else if(($teacherID==$id)&&($teacherPWD==$pwd)){
    $_SESSION["login"]="T";
    header("Location:teacher.php");
}else if(($stuID==$id)&&($stuPWD==$pwd)){
    $_SESSION["login"]="S";
    header("Location:stu.php");
}else{
    $_SESSION["login"]="No";
    header("Location:fail.php");
}

?>