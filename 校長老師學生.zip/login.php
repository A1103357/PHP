<html>
<head>
<meta charset="utf-8">
</head>
<body>
<form method="post" action="Result.php">
您的ID：<input type="text" name="id"><br/>
您的密碼：<input type="password" name="pwd"><br/>
<input type="submit">
<input type="reset">
</body>
</html>