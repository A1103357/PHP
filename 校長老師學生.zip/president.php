<?php
session_start();

if($_SESSION["login"]=="P"){

}else{
    header("Location:error.php");
}
?>

<html>
<head>
<meta charset="utf-8">
</head>
<body>
此處為校長頁面<br/>
若欲前往教師頁面<a href="teacher.php">請點選這裡</a>
</body>
</html>